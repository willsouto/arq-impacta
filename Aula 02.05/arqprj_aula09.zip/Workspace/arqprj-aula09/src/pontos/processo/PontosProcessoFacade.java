package pontos.processo;

import pontos.interfaces.*;

public class PontosProcessoFacade implements IPontosProcesso {
    private IPontosBusiness negocios;
    private Mapeador mapeador;
    public PontosProcessoFacade(IPontosBusiness negocios){
        this.negocios = negocios;
        mapeador = new Mapeador();
    }
    @Override
	public Mapeamento getMapeamento() {
		return mapeador.gerarMapeamento();
	}
    public int getPontos(int identificador, String letras, Mapeamento mapeamento){
	    int pontos = -1;
	    Participante p = negocios.find(identificador);
	    String senha = p.getSenha();
	    boolean autorizado = mapeador.validar(mapeamento, letras, senha);
	    if(autorizado){
	        pontos = p.getPontos();
	    }
	    return pontos;
  }
	
}
